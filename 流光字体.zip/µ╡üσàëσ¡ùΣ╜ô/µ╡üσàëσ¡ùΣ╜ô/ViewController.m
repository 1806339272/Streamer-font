//
//  ViewController.m
//  流光字体
//
//  Created by admin on 15/12/29.
//  Copyright © 2015年 admin. All rights reserved.
//

#import "ViewController.h"
#import "FBShimmeringView.h"
@interface ViewController ()
@property(nonatomic,strong)FBShimmeringView *shimmer;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
    
    
    self.label1.textColor = [UIColor redColor];
    self.shimmer = [[FBShimmeringView alloc]init];
    self.shimmer.frame = CGRectMake(0, 100, 320, 30);
    
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 320, 30)];
    label.textAlignment = NSTextAlignmentCenter;
    label.text = @"流光字体流光字体";
    label.textColor = [UIColor redColor];
     self.shimmer.contentView = label;
    [self.view addSubview:self.shimmer];

    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)action:(UIButton *)sender
{
    self.shimmer.shimmering = YES;
    self.label1.textColor = [UIColor redColor];
    self.shimmer.shimmeringPauseDuration = 0.1;

}

- (IBAction)end:(id)sender {
    self.shimmer.shimmering = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
